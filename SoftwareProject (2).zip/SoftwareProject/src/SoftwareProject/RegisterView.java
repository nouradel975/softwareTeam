package SoftwareProject;

public class RegisterView {

    AccountController ctr;

    RegisterView(){

        ctr = new AccountController();
    }

    void register(){

    }
}
