package SoftwareProject;

import java.util.List;

public class AccountController {

    private List<Account> mAccounts;

    void register(int id, String pass, String name, String email){

    }

}
