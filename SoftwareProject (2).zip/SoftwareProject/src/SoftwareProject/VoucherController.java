package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class VoucherController {

    List<VoucherCard> mVouchers;

    VoucherController(){

        mVouchers = new ArrayList<>();
    }

    void addVoucher(String expiry, int balance){
VoucherCard v=new VoucherCard();
v.setBalance(balance);
v.setExpiryDate(expiry);
mVouchers.add(v);

    }

    void removeVoucher(VoucherCard voucher){}
}
