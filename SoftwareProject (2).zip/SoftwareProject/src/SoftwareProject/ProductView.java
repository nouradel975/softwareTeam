package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class ProductView {

    ProductController productCtr;

    ProductView(){productCtr = new ProductController();}

    void addProduct(){}

    void removeProduct(){}

    void display(String name){
     Product p= productCtr.search(name);

        System.out.println("Name :"+p.getName()+"Price :"+p.getPrice() + "Category :"+p.getCategory()+"Brand :"+p.getBrand()+"Size :"+p.getSize()+"ID :"+p.getId()+"Color :"+p.getColor()+"Views :"+p.getViews()+"Orders :"+p.getOrders());

    }

}
