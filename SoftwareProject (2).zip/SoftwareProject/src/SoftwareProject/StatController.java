package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class StatController {

    String calStatistics(Store store){
        List<OnShelfProduct> l=new ArrayList<>();
        l=store.getAll();
        OnShelfProduct p= new OnShelfProduct();
        p=l.get(0);
        for (int i=0 ;i<l.size();i++)
        {
            if (l.get(i).getViews()>p.getViews())
            {
                p=l.get(i);
            }
        }
return p.product.getName();
    }
}
