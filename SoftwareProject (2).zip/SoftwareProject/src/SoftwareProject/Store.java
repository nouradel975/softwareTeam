package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class Store {

    private String name;
    private List<OnShelfProduct> mProduct;

    public Store() {}

    public Store(String name) {
        this.name = name;
        mProduct = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    void addProduct(Product product, int quantity){}

    void removeProduct(Product product){}

    List<OnShelfProduct> getAll(){}
}
