package SoftwareProject;

public class Product implements IStatistics {

    private String name;
    private float price;
    private String category;
    private Brand brand;
    private int size;
    private int id;
    private String color;
    private int views;
    private int orders;

    @Override
    public void setViews(int views) {

    }

    @Override
    public int getViews() {
        return 0;
    }

    @Override
    public void setOrders(int orders) {

    }

    @Override
    public int getOrders() {
        return 0;
    }

    @Override
    public void incrementViews() {

    }

    @Override
    public void incrementOrders() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
