package SoftwareProject;

public class AdminStatController {

    String calStatistics(){};
}
