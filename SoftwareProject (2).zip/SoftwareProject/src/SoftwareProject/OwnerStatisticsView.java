package SoftwareProject;

public class OwnerStatisticsView {

    StatController statCtr;
    Store store;

    public OwnerStatisticsView() {

        statCtr = new StatController();
        store = new Store();
    }
}
