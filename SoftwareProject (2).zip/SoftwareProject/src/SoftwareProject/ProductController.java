package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class ProductController {

    List<Product> mProducts;
    List<Product> mSuggests;

    ProductController() {

        mProducts = new ArrayList<>();
        mSuggests = new ArrayList<>();
    }

    void addProduct(String name, int price, String catogery, Brand brand, int id, String color) {
    }

    void removeProduct(Product product) {
    }

    Product search(String name){}

    List<Product> getAll(){ return mProducts; }

    void suggest(Product product){}

    public List<Product> getmSuggests() {
        return mSuggests;
    }


    public void productViewsNum ()
    {
        List<Product> pList=new ArrayList<>();
        pList=getAll();
        for (int i=0 ; i<pList.size() ;i++)
        {
            System.out.println("Product Name:"+pList.get(i).getName()+"Number of Views :"+pList.get(i).getViews());

        }
    }


}
