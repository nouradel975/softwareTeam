package SoftwareProject;

public class OnShelfProduct implements IStatistics{


    Product product;
    int quantity;
    int orders;
    int views;

    @Override
    public void setViews(int views) {

    }

    @Override
    public int getViews() {
        return 0;
    }

    @Override
    public void setOrders(int orders) {

    }

    @Override
    public int getOrders() {
        return 0;
    }

    @Override
    public void incrementViews() {

    }

    @Override
    public void incrementOrders() {

    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
