package SoftwareProject;

public class VoucherView {

    VoucherController voucherCtr;

    VoucherView(){ voucherCtr = new VoucherController();}

    void provideVoucher(){

        voucherCtr.addVoucher();
    }

    void removeVoucher(){}

}
