package SoftwareProject;

public interface IStatistics {

    void setViews(int views);

    int getViews();

    void setOrders(int orders);

    int getOrders();

    void incrementViews();

    void incrementOrders();

}
