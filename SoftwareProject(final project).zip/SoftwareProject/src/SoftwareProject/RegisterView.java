package SoftwareProject;

import java.util.Scanner;

public class RegisterView {

    AccountController ctr;

    RegisterView(){ ctr = new AccountController(); }

    Account register(String type,ProductController productCtr){

        Scanner sc = new Scanner(System.in);
        System.out.print("\nname: ");
        String name = sc.next();

        System.out.print("email: ");
        String email = sc.next();

        System.out.print("pass: ");
        String pass = sc.next();

        float wallet=0;
        if(type.equalsIgnoreCase("buyer")){

            System.out.print("wallet: ");
            wallet = sc.nextFloat();
        }
        Account acc = null;

        if(ctr.register(pass,name,email,type,wallet)) {
            System.out.println("\nwelcome :) , now you have an account");

            switch(type) {
                case "buyer":
                    acc= ctr.getBuyer(email);
                    break;
                case "owner":
                    acc= ctr.getOwner(email);
                    break;
                case "admin":
                    acc=ctr.getAdmin(email);
                    break;
            }
            return acc;
        }
        else {
            System.out.println("There is an account by this info.");
            return acc;
        }
    }

    Account login(String type) {

        Account login = null;
        Scanner sc = new Scanner(System.in);

        System.out.print("\nemail: ");
        String email = sc.next();

        System.out.print("pass: ");
        String pass = sc.next();

        int i=0;
        while (!ctr.login(email, pass).equalsIgnoreCase("buyer") &&
                !ctr.login(email, pass).equalsIgnoreCase("owner") &&
                !ctr.login(email, pass).equalsIgnoreCase("admin") && i<3) {

            System.out.println("something error!!\n");
            System.out.print("email: ");
            email = sc.next();

            System.out.print("pass: ");
            pass = sc.next();
            i++;
        }
        if(i == 3) {
            System.out.println("try again.");
            return login;
        }
        switch(type) {
            case "buyer":
                if(ctr.login(email,pass).equalsIgnoreCase("buyer"))
                    login = ctr.getBuyer(email);
            case "owner":
                if(ctr.login(email,pass).equalsIgnoreCase("owner"))
                    login = ctr.getOwner(email);
            case "admin":
                if(ctr.login(email,pass).equalsIgnoreCase("admin"))
                    login =ctr.getAdmin(email);
        }
        return login;
    }
}
