package SoftwareProject;

import java.util.*;

public class StoreOwner extends Account{

    List <Integer> stores;

    StoreOwner(){  stores=new ArrayList<>();}

    public void addStore(Store store) {
        stores.add(store.getID());
    }

    public int count() {
        return stores.size();
    }

    public void viewStores(StoreController ctr){

        System.out.println("you have "+stores.size()+" stores");
        for(int id: stores) {

            Store store = ctr.searchByID(id);
            System.out.println("store name: " + store.getName() + ", ID " + store.getID());
        }
    }

    public void removeStore(int ID) {

        for(int i=0;i<stores.size();++i) {
            int id = stores.get(i);
            if(id == ID)
                stores.remove(i);
        }
    }

    public boolean hasStore(int ID) {

        for(Integer id : stores) {
            if(id == ID)
                return true;
        }
        return false;
    }
    @Override
    public boolean equals(Object obj) {

        StoreOwner owner = (StoreOwner)obj;
        return (owner.email.equals(email) && owner.pass.equals(pass));
    }
}
