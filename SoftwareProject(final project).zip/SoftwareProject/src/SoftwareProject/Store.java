package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class Store {

    int storeID;
    String ownerMail;
    StoreOwner owner;
    private String name;
    ProductController productCtr;
    private List<OnShelfProduct> mProduct;

    public Store(String name,ProductController productCtr,StoreOwner owner,int id) {

        this.name = name;
        this.productCtr = productCtr;
        mProduct = new ArrayList<>();
        this.owner = owner;
        ownerMail = owner.email;
        this.storeID = id;
        owner.addStore(this);
    }

    Product searchByID(int id){

        for(Product p: productCtr.getAll()){
            if(p.getId() == id){
                return p;
            }
        }
        return null;
    }

    OnShelfProduct searchByName(String name){

        for(OnShelfProduct p: mProduct){
            if(p.product.getName().equalsIgnoreCase(name)){
                return p;
            }
        }
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    boolean search(OnShelfProduct product){

        for(OnShelfProduct p: mProduct){
            if(p.product.equals(product.product))
                return true;
        }
        return false;
    }

    boolean addProduct(Product product, int quantity){

        if(searchByID(product.getId()) != null){
            OnShelfProduct product1 = new OnShelfProduct(product);
            product1.quantity = quantity;
            if(!search(product1)) {
                mProduct.add(product1);
                return true;
            }
            else return false;
        }else
            return false;
    }

    boolean removeProduct(OnShelfProduct product){

        if(search(product)){
            mProduct.remove(product);
            return true;
        }
        else
            return false;
    }

    List<OnShelfProduct> copyToList(){

        List<OnShelfProduct> temp = new ArrayList<>();

        for(OnShelfProduct p:mProduct){
            temp.add(new OnShelfProduct(p.product, p.views, p.orders));
        }
        return temp;
    }

    List<OnShelfProduct> getAll(){ return mProduct; }

    @Override
    public boolean equals(Object obj) {

        Store store = (Store) obj;
        return (store.getName().equalsIgnoreCase(name) && owner.equals(store.owner));
    }

    public int getID() {
        return storeID;
    }
}
