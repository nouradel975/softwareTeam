package SoftwareProject;

import java.util.List;
import java.util.Scanner;

public class BuyerView {

    OrderController orderCtr;
    ProductController productCtr;
    Buyer buyer;
    StoreController storeCtr;
    VoucherController voucherCtr;

    public BuyerView(ProductController productCtr, VoucherController voucherCtr,StoreController storeCtr) {

        this.orderCtr = new OrderController(productCtr);
        this.productCtr = productCtr;
        this.buyer = new Buyer();
        this.storeCtr = storeCtr;
        this.voucherCtr = voucherCtr;
    }

    void setBuyer(Buyer buyer) { this.buyer = buyer; }

    void buy(){

        Scanner sc = new Scanner(System.in);

        OnShelfProduct onShelfProduct = null;

            System.out.print("\nwhat's the product you want to buy ? ");
            int id = sc.nextInt();

            for (Store s : storeCtr.getAll()) {
                for (OnShelfProduct osp : s.getAll()) {
                    if (osp.getProduct().getId() == id) {
                        onShelfProduct = osp;
                    }
                }
            }

            if(onShelfProduct == null) {
                System.out.println("No such product");
                return;
            }


        if(orderCtr.addOrder(buyer, onShelfProduct.product.getPrice() ,onShelfProduct)) {
            if (pay(onShelfProduct)) {
                System.out.println("Done.");
                System.out.println("now your wallet has " + buyer.wallet +"$.");
            }
            else
                System.out.println("there is an error!! (either you don't have enough money or voucher is expired.)");
        }
        else
            System.out.println("product not found!!");

    }

    boolean pay(OnShelfProduct product){

        System.out.print("\nwhat's the voucher card you want to buy by it ? ");
        Scanner sc = new Scanner(System.in);
        String id = sc.next();
        VoucherCard temp = voucherCtr.search(id);

        if(temp != null){
            boolean order = orderCtr.payByVoucher(buyer,product.product.getPrice(),temp);
            if(order) return true;
        }
        return false;
    }

    void search(){

        System.out.print("\nwhat's the product you want to search on ? ");
        Scanner sc = new Scanner(System.in);

        List<Product> products = productCtr.search(sc.next());

        for(Product p: products) {

            System.out.println("name: " + p.getName() + ", price: " + p.getPrice()
                    + ", category: " + p.getCategory() + ", color: " + p.getColor()
                    + ", brand: "+ p.getBrand().getName());
        }

        if(products.isEmpty())
            System.out.println("not founded!!");
    }

    void display(){

        List<Product> temp = productCtr.getAll();

        for(Product p: temp){
            System.out.println("product name: " + p.getName() + ", size: " + p.getSize()+ ", price: "
                            + p.getPrice() +", brand: " +p.getBrand().getName()
                            + ", color: " + p.getColor() + ", category: " + p.getCategory());
        }
    }

    void suggest(){

        System.out.print("\nPlease, suggest product: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();

        Product temp = new Product();
        temp.setName(name);

        System.out.print("ID: ");
        temp.setId(sc.nextInt());

        System.out.print("price: ");
        temp.setPrice(sc.nextFloat());

        System.out.print("category: ");
        temp.setCategory(sc.next());

        System.out.print("size: ");
        temp.setSize(sc.nextInt());

        System.out.print("color: ");
        temp.setColor(sc.next());

        if(productCtr.suggest(temp))
            System.out.println("\nthanks for your suggestion :)");
        else
            System.out.println("\nalready suggested");
    }
}
