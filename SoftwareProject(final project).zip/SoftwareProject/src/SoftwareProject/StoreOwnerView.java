package SoftwareProject;

import java.util.List;
import java.util.Scanner;

public class StoreOwnerView {

    ProductController productCtr;
    StoreController storeCtr;
    StoreOwner owner;

    public StoreOwnerView(ProductController productCtr) {

        owner = new StoreOwner();
        this.productCtr = productCtr;
    }

    void addStore() {

        System.out.print("\nstore name: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        if(storeCtr.addStore(name))
            System.out.println("Done.");
        else
            System.out.println("Can't add, it's already exist.");
    }

    void removeStore(){

        System.out.print("\nstore name: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        if(storeCtr.removeStore(name))
            System.out.println("Done.");
        else
            System.out.println("Can't remove, it's not exist.");
    }

    void addProduct() {

        System.out.print("\nproduct id: ");
        Scanner sc = new Scanner(System.in);

        if (owner.count() != 0) {
            Product product = null;

            int id = sc.nextInt();
            for (Product p : productCtr.getAll()) {
                if (p.getId() == id) {
                    product = p;
                    break;
                }
            }

            System.out.print("quantity: ");
            int quantity = sc.nextInt();
            owner.viewStores(storeCtr);
            System.out.print("\nstore id: ");
            int storeId = sc.nextInt();
            if (storeCtr.searchByID(storeId).addProduct(product, quantity))
                System.out.println("Done.");
            else
                System.out.println("Can't add (not exist in the system or already exist in the store.)");
        } else
            System.out.println("store not founded!!");
    }


    void removeProduct(){

        Scanner sc = new Scanner(System.in);
        System.out.print("\nproduct id: ");
        int id = sc.nextInt();
        OnShelfProduct product = new OnShelfProduct();
        owner.viewStores(storeCtr);
        System.out.print("\nstore id: ");
        int storeId = sc.nextInt();
        product.product.setId(id);

        if(storeCtr.searchByID(storeId).removeProduct(product))
            System.out.println("Done.");
        else
            System.out.println("Can't remove, not exist.");
    }

    void displayOneProduct(){

        Scanner sc = new Scanner(System.in);
        owner.viewStores(storeCtr);
        System.out.println();
        System.out.print("store id: ");
        int storeId = sc.nextInt();
        System.out.print("product name: ");
        String name = sc.next();
        Product temp = new Product();
        temp.setName(name);

        Product product = null;
        if(storeCtr.searchByID(storeId) != null && storeCtr.searchByID(storeId).searchByName(temp.getName()) != null)
            product = storeCtr.searchByID(storeId).searchByName(temp.getName()).product;

        if(product != null) {
            System.out.println("name: " + product.getName() + ", price: " +
                    product.getPrice() + ", category: " + product.getCategory() + ", brand: "
                    + product.getBrand().getName() + ", size: " + product.getSize()
                    + ", ID: " + product.getId() + ", color: " + product.getColor());
        }
    }

    void explore(){

        if(owner.count() != 0) {

            Scanner sc = new Scanner(System.in);
            owner.viewStores(storeCtr);
            System.out.print("store Id: ");
            int storeId=sc.nextInt();
            for (OnShelfProduct p : storeCtr.searchByID(storeId).getAll()) {
                System.out.println("product" + p.product.getId() + ": " + p.quantity);
            }
        }
    }

    void suggest(){

        System.out.print("\nPlease, suggest product: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();

        Product temp = new Product();
        temp.setName(name);

        System.out.print("ID: ");
        temp.setId(sc.nextInt());

        System.out.print("price: ");
        temp.setPrice(sc.nextFloat());

        System.out.print("category: ");
        temp.setCategory(sc.next());

        System.out.print("size: ");
        temp.setSize(sc.nextInt());

        System.out.print("color: ");
        temp.setColor(sc.next());

        if(productCtr.suggest(temp))
            System.out.println("\nthanks for your suggestion :)");
        else
            System.out.println("\nalready suggested");
    }

    public void viewsForEachPro () {

        if(owner.count() != 0) {

            Scanner sc = new Scanner(System.in);

            for (Store s : storeCtr.getAll()) {
                System.out.print("store name: " + s.getName() + "\t");
                for (OnShelfProduct product : s.getAll()) {
                    System.out.println("Product Name:" + product.product.getName() +
                            ", Views :" + product.getViews());
                }
                if(s.getAll().isEmpty())
                    System.out.println("no products.");
            }
        }
        else
            System.out.println("you don't have store :( !!");
    }

    public void setOwnerandController(StoreOwner owner, StoreController storeCtr) {

        this.owner = owner;
        this.storeCtr = storeCtr;
        storeCtr.setOwner(owner);
    }
}
