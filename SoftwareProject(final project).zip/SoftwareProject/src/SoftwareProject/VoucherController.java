package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class VoucherController {

    List<VoucherCard> mVouchers;

    VoucherController(){ mVouchers = new ArrayList<>(); }

    VoucherCard search(String id){

        for(VoucherCard v: mVouchers){
            if(id.equals(v.id))
                return v;
        }
        return null;
    }

    boolean addVoucher(String expiry, float balance, String id){

        if(search(id) == null) {
            VoucherCard voucher = new VoucherCard();
            voucher.setBalance(balance);
            voucher.setExpiryDate(expiry);
            voucher.id = id;
            mVouchers.add(voucher);
            return true;
        }
        else
            return false;
    }

    boolean removeVoucher(String id){

        if(search(id) != null){
            mVouchers.remove(search(id));
            return true;
        }
        else
            return false;
    }

}
