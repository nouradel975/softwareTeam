package SoftwareProject;

import java.util.Comparator;
import java.util.List;

public class AdminStatController {

    private ProductController productCtr;

    public AdminStatController(ProductController productCtr) { this.productCtr = productCtr; }

    String calStatistics(){

        String output = "";

        List<Product> temp = productCtr.copyTheList();
        temp.sort(Comparator.comparing(Product::getViews));
        output += "the most viewed product is: " + temp.get(temp.size()-1).getName() + "\n";

        temp.sort(Comparator.comparing(Product::getOrders));
        output += "the most ordered product is: " + temp.get(temp.size()-1).getName() + "\n";

        return output;
    }
}
