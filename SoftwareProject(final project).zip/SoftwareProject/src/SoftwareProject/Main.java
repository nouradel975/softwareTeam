package SoftwareProject;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int choice;
        StoreOwner owner = null;
        Buyer buyer = null;

        BrandView brandView = new BrandView();
        RegisterView rv = new RegisterView();
        ProductView productView = new ProductView(brandView);
        AdminStatisticsView statisticsView = new AdminStatisticsView(productView.productCtr);
        StoreController storeCtr = new StoreController(productView.productCtr);
        StoreOwnerView store = new StoreOwnerView(productView.productCtr);
        OwnerStatisticsView ownerView = new OwnerStatisticsView();
        VoucherView voucher = new VoucherView();
        BuyerView buyerView = new BuyerView(productView.productCtr,voucher.voucherCtr,storeCtr);

        System.out.println("\t \t \t \t \t \t welcome to our program :)");

        boolean loop = true, exit;

        while (loop) {
            System.out.println("\n \n ----------------------------------------------------------------------------------------");
            System.out.println("please choose \n1.login \n2.register \n3.exit\n");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("1.as user \n2.as owner \n3.as admin \n");
                    choice = sc.nextInt();
                    switch (choice) {
                        case 1:
                            buyer =(Buyer) rv.login("buyer");

                            if (buyer != null) {
                                buyerView.setBuyer(buyer);
                                exit = true;
                                while (exit) {
                                    System.out.println("\n \n \t \t \t \t what do you want? \n1.buy \n2.search " +
                                            "\n3.display all \n4.suggest product \n5.suggest brand \n6.exit");
                                    choice = sc.nextInt();

                                    switch (choice) {

                                        case 1:
                                            buyerView.buy();
                                            break;
                                        case 2:
                                            buyerView.search();
                                            break;
                                        case 3:
                                            buyerView.display();
                                            break;
                                        case 4:
                                            buyerView.suggest();
                                            break;
                                        case 5:
                                            brandView.suggest();
                                            break;
                                        case 6:
                                            exit = false;
                                            break;
                                        default:
                                            System.out.println("ERROR!!");
                                    }
                                }
                            }
                            break;
                        case 2:
                            owner = (StoreOwner) rv.login("owner");

                            if (owner != null) {
                                exit = true;
                                store.setOwnerandController(owner,storeCtr);
                                ownerView.setStoreCtr(store);

                                while (exit) {
                                    System.out.println("\n \n \t \t \t \t what do you want?" +
                                            " \n1.add store \n2.add product to your store" +
                                            " \n3.remove store \n4.remove product from your store \n" +
                                            "5.suggest product \n6.suggest brand \n" +
                                            "7.explore \n8.view specific product \n" +
                                            "9.views for all products" +
                                            " \n10.store statistics \n11.exit");
                                    choice = sc.nextInt();

                                    switch (choice) {

                                        case 1:
                                            store.addStore();
                                            break;
                                        case 2:
                                            if(productView.displayForAdd()) {
                                                System.out.println();
                                                store.addProduct();
                                            }
                                            break;
                                        case 3:
                                            store.removeStore();
                                            break;
                                        case 4:
                                            store.removeProduct();
                                            break;
                                        case 5:
                                            store.suggest();
                                            break;
                                        case 6:
                                            brandView.suggest();
                                            break;
                                        case 7:
                                            store.explore();
                                            break;
                                        case 8:
                                            store.displayOneProduct();
                                            break;
                                        case 9:
                                            store.viewsForEachPro();
                                            break;
                                        case 10:
                                            ownerView.calStatistics();
                                            break;
                                        case 11:
                                            exit = false;
                                            break;
                                        default:
                                            System.out.println("ERROR!!");
                                    }
                                }
                            }
                            break;
                        case 3:

                            if (rv.login("admin")!=null) {
                                exit = true;
                                while (exit) {
                                    System.out.println("\n \n \t \t \t \t what do you want?" +
                                            " \n1.add product \n2.remove product" +
                                            " \n3.add brand \n4.remove brand \n" +
                                            "5.add voucher \n6.remove voucher \n7.display all products \n" +
                                            "8.statistics \n9.suggested products \n10.suggested brands" +
                                            " \n11.exit \n");

                                    choice = sc.nextInt();
                                    switch (choice) {

                                        case 1:
                                            if(brandView.viewBrands()) {
                                                System.out.println();
                                                productView.addProduct();
                                            }
                                            break;
                                        case 2:
                                            productView.removeProduct();
                                            break;
                                        case 3:
                                            brandView.addBrand();
                                            break;
                                        case 4:
                                            brandView.removeBrand();
                                            break;
                                        case 5:
                                            voucher.provideVoucher();
                                            break;
                                        case 6:
                                            voucher.removeVoucher();
                                            break;
                                        case 7:
                                            productView.display();
                                            break;
                                        case 8:
                                            statisticsView.calStatistics();
                                            break;
                                        case 9:
                                            productView.getProductSuggestion();
                                            break;
                                        case 10:
                                            brandView.getSuggestedBrands();
                                            break;
                                        case 11:
                                            exit = false;
                                            break;
                                        default:
                                            System.out.println("ERROR!!");
                                    }
                                }
                            }
                            break;
                        default:
                            System.out.println("try again");
                    }
                    break;
                case 2:
                    System.out.println("1.as user \n2.as owner \n3.as admin \n");
                    choice = sc.nextInt();
                    switch (choice) {
                        case 1:
                            buyer = (Buyer) rv.register("buyer",productView.productCtr);
                            if (buyer != null) {

                                buyerView.setBuyer(buyer);
                                exit = true;
                                while (exit) {
                                    System.out.println("\n \n \t \t \t \t what do you want? " +
                                            "\n1.buy \n2.search \n3.display all " +
                                            "\n4.suggest product \n5.suggest brand \n6.exit \n");
                                    choice = sc.nextInt();

                                    switch (choice) {

                                        case 1:
                                            buyerView.buy();
                                            break;
                                        case 2:
                                            buyerView.search();
                                            break;
                                        case 3:
                                            buyerView.display();
                                            break;
                                        case 4:
                                            buyerView.suggest();
                                            break;
                                        case 5:
                                            brandView.suggest();
                                            break;
                                        case 6:
                                            exit = false;
                                            break;
                                        default:
                                            System.out.println("ERROR!!");
                                    }
                                }
                            }
                            break;
                        case 2:
                            owner = (StoreOwner) rv.register("owner",productView.productCtr);
                            if (owner != null) {
                                store.setOwnerandController(owner,storeCtr);
                                ownerView.setStoreCtr(store);
                                exit = true;
                                while (exit) {
                                    System.out.println("\n \n \t \t \t \t what do you want?" +
                                            " \n1.add store \n2.add product to your store" +
                                            " \n3.remove store \n4.remove product from your store \n" +
                                            "5.suggest product \n6.suggest brand \n"
                                            +"7.explore \n8.view specific product \n" +
                                            "9.views for all products \n10.store statistics \n11.exit \n");
                                    choice = sc.nextInt();

                                    switch (choice) {

                                        case 1:
                                            store.addStore();
                                            break;
                                        case 2:
                                            if (productView.displayForAdd()) {
                                                System.out.println();
                                                store.addProduct();
                                            }
                                            break;
                                        case 3:
                                            store.removeStore();
                                            break;
                                        case 4:
                                            store.removeProduct();
                                            break;
                                        case 5:
                                            store.suggest();
                                            break;
                                        case 6:
                                            brandView.suggest();
                                            break;
                                        case 7:
                                            store.explore();
                                            break;
                                        case 8:
                                            store.displayOneProduct();
                                            break;
                                        case 9:
                                            store.viewsForEachPro();
                                            break;
                                        case 10:
                                            ownerView.calStatistics();
                                            break;
                                        case 11:
                                            exit = false;
                                            break;
                                        default:
                                            System.out.println("ERROR!!");
                                    }
                                }
                            }
                            break;
                        case 3:
                            if (rv.register("admin",productView.productCtr) != null) {

                                exit = true;
                                while (exit) {
                                    System.out.println("\n \n \t \t \t \t what do you want?" +
                                            " \n1.add product \n2.remove product" +
                                            " \n3.add brand \n4.remove brand \n" +
                                            "5.add voucher \n6.remove voucher \n7.display all products \n" +
                                            "8.statistics \n9.suggested products \n10.suggested brands" +
                                            " \n11.exit");

                                    choice = sc.nextInt();
                                    switch (choice) {

                                        case 1:
                                            if(brandView.viewBrands()) {
                                                System.out.println();
                                                productView.addProduct();
                                            }
                                            break;
                                        case 2:
                                            productView.removeProduct();
                                            break;
                                        case 3:
                                            brandView.addBrand();
                                            break;
                                        case 4:
                                            brandView.removeBrand();
                                            break;
                                        case 5:
                                            voucher.provideVoucher();
                                            break;
                                        case 6:
                                            voucher.removeVoucher();
                                            break;
                                        case 7:
                                            productView.display();
                                            break;
                                        case 8:
                                            statisticsView.calStatistics();
                                            break;
                                        case 9:
                                            productView.getProductSuggestion();
                                            break;
                                        case 10:
                                            brandView.getSuggestedBrands();
                                            break;
                                        case 11:
                                            exit = false;
                                            break;
                                        default:
                                            System.out.println("ERROR!!");
                                    }
                                }
                            }
                    }
                    break;
                case 3:
                    loop = false;
                    System.out.println("ya welcome :D");
                    break;
                default:
                    System.out.println("try again");
                    break;
            }
        }
    }
}

