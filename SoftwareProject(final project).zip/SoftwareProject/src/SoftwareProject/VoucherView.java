package SoftwareProject;

import java.util.Scanner;

public class VoucherView {

    VoucherController voucherCtr;

    VoucherView(){ voucherCtr = new VoucherController();}

    void provideVoucher(){

        Scanner sc = new Scanner(System.in);

        System.out.print("\nyou want to provide voucher card ,, what's the id: ");
        String id = sc.next();

        System.out.print("balance: ");
        float balance = sc.nextFloat();

        System.out.print("expiry date: ");
        String date = sc.next();

        if(voucherCtr.addVoucher(date,balance,id))
            System.out.println("Done.");
        else
            System.out.println("voucher is already exists");
    }

    void removeVoucher(){

        Scanner sc = new Scanner(System.in);

        System.out.print("\nyou want to remove voucher card ,, what's the id: ");
        String id = sc.next();

        if(voucherCtr.removeVoucher(id))
            System.out.println("Done.");
        else
            System.out.println("Can't remove, it's not exist.");

    }
}
