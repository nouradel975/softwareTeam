package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class StoreController {

    StoreOwner owner;
    private List<Store> mStores;
    ProductController productCtr;
    int ID;

    StoreController(ProductController productCtr){

        mStores = new ArrayList<>();
        this.productCtr = productCtr;
        ID=0;
    }

    public void setProductController(ProductController productCtr) {
        this.productCtr = productCtr;
    }

    public void setOwner(StoreOwner owner) {
        this.owner=owner;
    }

    Store search(String name){

        for(Store s: mStores){
            if(s.getName().equalsIgnoreCase(name) && owner.hasStore(s.getID()))
                return s;
        }
        return null;
    }
    Store searchByID(int id) {
        for(Store s: mStores) {
            if(s.getID()==id) {
                return s;
            }
        }
        return null;
    }

    boolean addStore(String name){

        Store store = search(name);

        if(store != null){
            return false;
        }
        else{
            store = new Store(name,productCtr,owner,ID);
            mStores.add(store);
            ID++;
            return true;
        }
    }

    boolean removeStore(String name){

        Store store = search(name);

        if(store != null){
            store.getAll().clear();
            owner.removeStore(store.getID());
            mStores.remove(store);
            return true;
        }
        else{
            return false;
        }
    }

    List<Store> getAll(){ return mStores; }

}
