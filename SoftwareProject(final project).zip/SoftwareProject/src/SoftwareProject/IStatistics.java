package SoftwareProject;

public interface IStatistics {

    int getViews();

    void setViews(int views);

    void setOrders(int orders);

    int getOrders();

    void incrementViews();

    void incrementOrders();

}
