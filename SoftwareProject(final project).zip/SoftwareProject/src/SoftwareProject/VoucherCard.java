package SoftwareProject;

public class VoucherCard {

    String expiryDate;
    float balance;
    String id;

    public VoucherCard(){}

    public VoucherCard(String id){ this.id = id; }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }
}
