package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class OrderController {

    protected List<Order> mOrders;
    ProductController productCtr;

    public OrderController(ProductController productCtr){

        this.productCtr = productCtr;
        mOrders = new ArrayList<>();
    }

    public boolean addOrder(Buyer buyer, float invoice, OnShelfProduct product){

        if(product != null && product.quantity > 0) {
            mOrders.add(new Order(product, buyer, invoice));
            product.incrementOrders();
            product.quantity--;
            return true;
        }
        return false;
    }

    public boolean payByVoucher(Buyer buyer, float price, VoucherCard voucherCard){

        if((price - (price * voucherCard.balance)) <= buyer.wallet) {
            buyer.wallet -= (price - (price * voucherCard.balance));
            return true;
        }
        return false;
    }

}
