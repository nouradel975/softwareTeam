package SoftwareProject;

import java.util.Scanner;

public class BrandView {

    BrandController brandCtr;

    BrandView(){ brandCtr = new BrandController();}

    void addBrand(){

        System.out.print("\nwhat's the name of brand ? ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        if(brandCtr.addBrand(name))
            System.out.println("Done.");
        else
            System.out.println("This brand is already found");

    }

    void removeBrand(){

        System.out.print("\nWhat's the brand you want to remove it ? ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        if(brandCtr.removeBrand(name))
            System.out.println("Done.");
        else
            System.out.println("Brand not founded.");
    }

    void suggest(){

        Scanner sc = new Scanner(System.in);
        System.out.print("brand name: ");
        Brand brand = new Brand();
        brand.setName(sc.next());
        if(brandCtr.suggest(brand))
            System.out.println("thanks for your suggestion.");
        else
            System.out.println("already suggested.");

    }

    boolean viewBrands(){

        if(!brandCtr.brands.isEmpty()) {
            System.out.println("\n \t \t \t \t brands in the platform: ");
            for (Brand b : brandCtr.brands) {
                System.out.print(b.getName() + "\t");
            }
            return true;
        }
        else {
            System.out.println("no brands in the platform, add brand first");
            return false;
        }
    }

    void getSuggestedBrands(){

        if(!brandCtr.suggestes.isEmpty()) {
            for (Brand b : brandCtr.suggestes) {
                System.out.print(b.getName() + "\t");
            }
        }
        else
            System.out.println("no suggestions.");
    }
}
