package SoftwareProject;

import java.util.Scanner;

public class OwnerStatisticsView {

    StatController statCtr;
    StoreOwnerView store;

    public OwnerStatisticsView(){ statCtr = new StatController();}

    void setStoreCtr(StoreOwnerView store){ this.store = store;}

    void calStatistics() {

        Scanner sc = new Scanner(System.in);
        System.out.println(" \nstore name:");

        System.out.println(statCtr.calStatistics(store.storeCtr.search(sc.next())));
    }
}
