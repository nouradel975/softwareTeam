package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class ProductController {

    List<Product> mProducts;
    List<Product> mSuggests;

    ProductController() {

        mProducts = new ArrayList<>();
        mSuggests = new ArrayList<>();
    }

    String addProduct(Product product,BrandController brandCtr) {

        String output = "";

        Product temp = search(product.getId(),mProducts);
        Brand brand = brandCtr.search(product.getBrand().getName(),brandCtr.brands);

        if (temp != null) {
            output = "product";
        }
        else if(brand == null) {
            output = "brand";
        }
        else{
            mProducts.add(product);
        }
        return output;
    }

    boolean removeProduct(int id) {

        Product product = search(id,mProducts);
        if(product != null){
            mProducts.remove(product);
            return true;
        }
        else {
            return false;
        }
    }

    public List<Product> search(String name) {

        List<Product>  products = new ArrayList<>();
        for (Product product : mProducts) {
            if (product.getName().equalsIgnoreCase(name)) {
                products.add(product);
                product.incrementViews();
            }
        }
        return products;
    }

    public Product search(int id, List<Product> products) {

        for (Product p : products) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    List<Product> getAll(){ return mProducts; }

    boolean suggest(Product product) {

        if(search(product.getId(),mSuggests) == null && search(product.getId(),mProducts) == null) {
            mSuggests.add(product);
            return true;
        }
        else
            return false;
    }

    List<Product> copyTheList(){

        List<Product> products = new ArrayList<>();
        Product temp = new Product();

        for(Product p: mProducts){
            temp.setId(p.getId());
            temp.setName(p.getName());
            temp.setViews(p.getViews());
            temp.setOrders(p.getOrders());
            products.add(temp);
        }
        return products;
    }

}
