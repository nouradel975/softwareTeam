package SoftwareProject;

public class Admin extends Account {}
