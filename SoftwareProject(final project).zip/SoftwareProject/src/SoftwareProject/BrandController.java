package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class BrandController {

    List<Brand> brands;
    List<Brand> suggestes;

    BrandController(){

        brands = new ArrayList<>();
        suggestes = new ArrayList<>();
    }


    Brand search(String name, List<Brand> brands){

        for (Brand brand : brands) {
            if (brand.getName().equalsIgnoreCase(name)) {
                return brand;
            }
        }
        return null;
    }



    boolean addBrand(String name){

        Brand brand = search(name,brands);

        if (brand != null) {
           return false;
        } else {
            Brand b = new Brand();
            b.setName(name);
            brands.add(b);
            return true;
        }
    }

    boolean removeBrand(String name){

        Brand brand = search(name,brands);

        if(brand != null){
            brands.remove(brand);
            return true;
        }
        else {
           return false;
        }
    }

    boolean suggest(Brand brand){

        if(search(brand.getName(),suggestes) == null && search(brand.getName(),brands) == null) {
            suggestes.add(brand);
            return true;
        }
        else
            return false;
    }

    public List<Brand> getSuggestes() {
        return suggestes;
    }

}
