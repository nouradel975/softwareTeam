package SoftwareProject;

public class AdminStatisticsView {

    AdminStatController adminStatCtr;

    AdminStatisticsView(ProductController productCtr){

        adminStatCtr = new AdminStatController(productCtr);
    }

    void calStatistics(){

        System.out.println("\n"+adminStatCtr.calStatistics());
    }
}
