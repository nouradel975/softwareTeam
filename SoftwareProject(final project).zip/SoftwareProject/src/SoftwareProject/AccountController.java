package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class AccountController {

    private List<Account> buyers;
    private List<Account> storeOwners;
    private List<Account> admins;

    AccountController(){

        buyers = new ArrayList<>();
        storeOwners = new ArrayList<>();
        admins = new ArrayList<>();
    }

    boolean register(String pass, String name, String email, String type, float wallet) {

        boolean register = false;

        if (type.equalsIgnoreCase("buyer")) {

            Buyer buyer = new Buyer();
            buyer.setWallet(wallet);
            buyer.setEmail(email);
            buyer.setName(name);
            buyer.setPass(pass);

            if (!search(buyer, buyers) && !search(buyer,storeOwners) && !search(buyer,admins)) {
                buyers.add(buyer);
                register = true;
            }
        } else if (type.equalsIgnoreCase("owner")) {

            StoreOwner storeOwner = new StoreOwner();
            storeOwner.setEmail(email);
            storeOwner.setName(name);
            storeOwner.setPass(pass);
            if (!search(storeOwner, buyers) && !search(storeOwner,storeOwners) && !search(storeOwner,admins)) {
                storeOwners.add(storeOwner);
                register = true;
            }
        } else if (type.equalsIgnoreCase("admin")) {

            Admin admin = new Admin();
            admin.setEmail(email);
            admin.setName(name);
            admin.setPass(pass);
            if (!search(admin, buyers) && !search(admin,storeOwners) && !search(admin,admins)) {
                admins.add(admin);
                register = true;
            }
        }
        return register;
    }

    private boolean search(Account account, List<Account> accounts){

        for(Account a: accounts){
            if(a.email.equals(account.email) && a.pass.equals(account.pass))
                return  true;
        }
        return false;
    }

    String login(String email, String pass) {

        Account account = new Account();
        account.email = email;
        account.pass = pass;

        String login = "";

        if(search(account, buyers))
            login = "buyer";
        else if(search(account,storeOwners))
            login = "owner";
        else if(search(account,admins))
            login = "admin";

        return login;
    }
    Account getOwner(String email) {
        for(Account so:storeOwners) {
            if(email.equalsIgnoreCase(so.email))
                return  so;
        }
        return null;
    }
    Account getBuyer(String email) {
        for(Account b:buyers) {
            if(email.equalsIgnoreCase(b.email))
                return  b;
        }
        return null;
    }
    Account getAdmin(String email) {
        for(Account a:admins) {
            if(email.equalsIgnoreCase(a.email))
                return  a;
        }
        return null;
    }
}
