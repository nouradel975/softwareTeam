package SoftwareProject;

import java.util.List;
import java.util.Scanner;

public class ProductView {

    ProductController productCtr;
    BrandView brandView;

    ProductView(BrandView brandView){

        this.brandView = brandView;
        productCtr = new ProductController();
    }

    void addProduct(){

        Scanner sc = new Scanner(System.in);
        Product product = new Product();

        System.out.println("\nyou want to add product,, so please enter it's info.");
        System.out.print("product name: ");
        product.setName(sc.next());

        System.out.print("id: ");
        product.setId(sc.nextInt());

        System.out.print("price: ");
        product.setPrice(sc.nextFloat());

        System.out.print("size: ");
        product.setSize(sc.nextInt());

        System.out.print("category: ");
        product.setCategory(sc.next());

        System.out.print("color: ");
        product.setColor(sc.next());

        System.out.print("brand: ");
        Brand brand = new Brand();
        brand.setName(sc.next());
        product.setBrand(brand);

        if(productCtr.addProduct(product,brandView.brandCtr).equalsIgnoreCase(""))
            System.out.println("Done.");
        else if(productCtr.addProduct(product,brandView.brandCtr).equalsIgnoreCase("product"))
            System.out.println("This Product is already");
        else if(productCtr.addProduct(product,brandView.brandCtr).equalsIgnoreCase("brand"))
            System.out.println("brand not exist, add it first.");
    }

    void removeProduct(){

        Scanner sc = new Scanner(System.in);
        System.out.print("\nWhat's the id of the product you want to remove ? ");
        int id = sc.nextInt();

        if(productCtr.removeProduct(id))
            System.out.println("Done.");
        else
            System.out.println("Product not founded.");
    }

    void getProductSuggestion(){

        if(!productCtr.mSuggests.isEmpty()) {
            for (Product product : productCtr.mSuggests) {
                System.out.println("product name: " + product.getName() + ", size: "
                        + product.getSize() + ", price: "
                        + product.getPrice() + ", color: " + product.getColor()
                        + ", category: " + product.getCategory());
            }
        }else
            System.out.println("no suggestions.");
    }

    boolean displayForAdd(){

        List<Product> products = productCtr.getAll();

        if(!products.isEmpty()) {
            System.out.println("\n \t \t \t \t \tproducts on platform");
            for (Product p : products) {
                System.out.print("\nproduct name: " + p.getName() + ", product ID: " + p.getId());
            }
            return true;
        }
        else {
            System.out.println("no products in the platform.");
            return false;
        }
    }

    void display(){

        List<Product> temp = productCtr.getAll();

        if(!temp.isEmpty()) {
            for (Product p : temp) {
                System.out.println("product name: " + p.getName() + ", size: " + p.getSize() + ", price: "
                        + p.getPrice() + ", brand: " + p.getBrand().getName()
                        + ", color: " + p.getColor() + ", category: " + p.getCategory());
            }
        }
        else
            System.out.println("no products in the platform.");
    }
}
