package SoftwareProject;

import java.util.Comparator;
import java.util.List;

public class StatController {

    String calStatistics(Store store){

        String output = "";

        List<OnShelfProduct> products = store.copyToList();
        products.sort(Comparator.comparing(OnShelfProduct::getViews));

        output += "the most viewed in the the store: " + products.get(products.size()-1).product.getName();

        return output;
    }
}
