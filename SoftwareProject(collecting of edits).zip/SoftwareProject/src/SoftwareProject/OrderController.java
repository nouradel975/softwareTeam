package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class OrderController {

    protected List<Order> mOrders;
    ProductController productCtr;

    public OrderController() { mOrders = new ArrayList<>(); }

    public OrderController(ProductController productCtr){ this.productCtr = productCtr; }

    public List<Order> getmOrders() { return mOrders; }

    public void setmOrders(List<Order> mOrders) { this.mOrders = mOrders; }


    Order search(OnShelfProduct product){

        for(Order o: mOrders){
            if(o.getProduct() == product)
                return o;
        }
        return null;
    }

    public boolean addOrder(Buyer buyer, float invoice, OnShelfProduct product){

        product.incrementOrders();
        if(productCtr.search(product.product.getName()) != null) {
            mOrders.add(new Order(product, buyer, invoice));
            return true;
        }
        return false;
    }

    public boolean payByVoucher(Buyer buyer, float price, VoucherCard voucherCard){

        String date = "2017-12-31";

        if(date.compareTo(voucherCard.expiryDate) < 0
                && price*voucherCard.balance < buyer.wallet) {
            buyer.wallet -= (price * voucherCard.balance);
            return true;
        }
        return false;
    }

}
