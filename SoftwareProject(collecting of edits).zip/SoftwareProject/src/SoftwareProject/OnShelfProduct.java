package SoftwareProject;

public class OnShelfProduct implements IStatistics{

    Product product;
    int quantity = 0;
    int views = 0;
    int orders = 0;


    public OnShelfProduct(Product product) {
        this.product = product;
    }

    public OnShelfProduct() {}

    public OnShelfProduct(Product product, int views, int orders) {

        this.product = product;
        this.orders = orders;
        this.views = views;
    }

    @Override
    public int getViews() {
        return views;
    }

    @Override
    public void setViews(int views) { this.views = views; }

    @Override
    public void setOrders(int orders) { this.orders = orders; }

    @Override
    public int getOrders() { return orders; }

    @Override
    public void incrementViews() { views++; }

    @Override
    public void incrementOrders() { orders++; }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
