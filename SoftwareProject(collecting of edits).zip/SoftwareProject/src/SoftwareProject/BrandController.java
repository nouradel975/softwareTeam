package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class BrandController {

    List<Brand> brands;
    List<Brand> suggestes;

    BrandController(){

        brands = new ArrayList<>();
        suggestes = new ArrayList<>();
    }


    private Brand search(String name){

        for (Brand brand : brands) {
            if (brand.getName().equalsIgnoreCase(name)) {
                return brand;
            }
        }
        return null;
    }

    boolean addBrand(String name){

        Brand brand = search(name);

        if (brand != null) {
           return false;
        } else {
            Brand b = new Brand();
            b.setName(name);
            brands.add(b);
            return true;
        }
    }

    boolean removeBrand(String name){

        Brand brand = search(name);

        if(brand != null){
            brands.remove(brand);
            return true;
        }
        else {
           return false;
        }
    }

    void suggest(Brand brand){

        if(search(brand.getName()) != null) {
            suggestes.add(brand);
            System.out.println("suggested.");
        }
        else
            System.out.println("rejected.");
    }

    public List<Brand> getSuggestes() {
        return suggestes;
    }

}
