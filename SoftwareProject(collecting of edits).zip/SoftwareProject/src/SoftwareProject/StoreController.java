package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class StoreController {

    private List<Store> mStores;

    StoreController(){ mStores = new ArrayList<>();}

    Store search(String name){

        for(Store s: mStores){
            if(s.getName().equalsIgnoreCase(name))
                return s;
        }
        return null;
    }

    boolean addStore(String name){

        Store store = search(name);

        if(store != null){
            return false;
        }
        else{
            store = new Store(name);
            mStores.add(store);
            return true;
        }
    }

    boolean removeStore(String name){

        Store store = search(name);

        if(store != null){
            mStores.remove(store);
            return true;
        }
        else{
            return false;
        }
    }

    List<Store> getAll(){ return mStores; }

}
