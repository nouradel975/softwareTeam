package SoftwareProject;

import java.util.List;
import java.util.Scanner;

public class BuyerView {

    OrderController orderCtr;
    ProductController productCtr;
    Buyer buyer;
    StoreOwner storeCtr;
    VoucherController voucherCtr;

    BuyerView(){

        orderCtr = new OrderController();
        productCtr = new ProductController();
        buyer = new Buyer();
        storeCtr = new StoreOwner();
        voucherCtr = new VoucherController();
    }

    public BuyerView(OrderController orderCtr, ProductController productCtr,
                     Buyer buyer, StoreOwner storeCtr, VoucherController voucherCtr) {

        this.orderCtr = orderCtr;
        this.productCtr = productCtr;
        this.buyer = buyer;
        this.storeCtr = storeCtr;
        this.voucherCtr = voucherCtr;
    }

    void buy(){

        System.out.print("what's the product you want to buy ? ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        OnShelfProduct onShelfProduct = new OnShelfProduct(productCtr.search(name));

        if(orderCtr.addOrder(buyer, onShelfProduct.product.getPrice() ,onShelfProduct)) {
            if (pay(onShelfProduct))
                System.out.println("Done.");
            else
                System.out.println("there is an error!! (either you don't have enough money or voucher is expired.)");
        }
        else
            System.out.println("product not found!!");

    }

    boolean pay(OnShelfProduct product){

        System.out.print("what's the voucher card you want to buy by it ? ");
        Scanner sc = new Scanner(System.in);
        String id = sc.next();
        VoucherCard temp = voucherCtr.search(id);

        if(temp != null){
            boolean order = orderCtr.payByVoucher(buyer,product.product.getPrice(),temp);

            if(order) return true;
        }
        return false;
    }

    void search(){

        System.out.print("what's the product you want to search on ? ");
        Scanner sc = new Scanner(System.in);

        Product temp = productCtr.search(sc.next());
        if(temp != null) {
            System.out.println("name: " + temp.getName() + ", price: " + temp.getPrice()
                    + ", category: " + temp.getCategory() + ", color: " + temp.getColor()
                    + ", brand" + temp.getBrand().getName());
            temp.incrementViews();
        }
        else
            System.out.println("not found!!");
    }

    void display(){

        List<Product> temp = productCtr.getAll();

        for(Product p: temp){
            System.out.println("product name: " + p.getName() + ", size: " + p.getSize()+ ", price: "
                            + p.getPrice() +", brand: " +p.getBrand().getName()
                            + ", color: " + p.getColor() + ", category: " + p.getCategory());
        }
    }

}
