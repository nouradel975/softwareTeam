package SoftwareProject;

import java.util.Comparator;
import java.util.List;

public class AdminStatController {

    private ProductController productCtr;

    AdminStatController(){ productCtr = new ProductController();}

    public AdminStatController(ProductController productCtr) { this.productCtr = productCtr; }

    String calStatistics(){

        String output = "";

        List<Product> temp = productCtr.copyTheList();

        temp.sort(Comparator.comparing(Product::getViews).reversed());
        output += "the most viewed product is: " + temp.get(0).getName() + "\n";

        temp.sort(Comparator.comparing(Product::getOrders).reversed());
        output += "the most ordered product is: " + temp.get(0).getName() + "\n";

        return output;
    }
}
