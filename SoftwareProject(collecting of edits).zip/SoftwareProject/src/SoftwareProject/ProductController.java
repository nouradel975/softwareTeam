package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class ProductController {

    List<Product> mProducts;
    List<Product> mSuggests;

    ProductController() {

        mProducts = new ArrayList<>();
        mSuggests = new ArrayList<>();
    }

    boolean addProduct(Product product) {

        Product temp = search(product.getName());

        if (temp != null) {
            return false;
        } else {
            mProducts.add(product);
            return true;
        }
    }

    boolean removeProduct(String name) {

        Product product = search(name);
        if(product != null){
            mProducts.remove(product);
            return true;
        }
        else {
            return false;
        }
    }

    public Product search(String name) {

        for (Product product : mProducts) {
            if (product.getName().equalsIgnoreCase(name)) {
                return product;
            }
        }
        return null;
    }

    List<Product> getAll(){ return mProducts; }

    void suggest(Product product) {

        if(search(product.getName()) != null) {
            mSuggests.add(product);
            System.out.println("suggested.");
        }
        else
            System.out.println("rejected.");
    }

    public List<Product> getmSuggests() {
        return mSuggests;
    }

    List<Product> copyTheList(){

        List<Product> products = new ArrayList<>();
        Product temp = new Product();

        for(Product p: mProducts){
            temp.setId(p.getId());
            temp.setName(p.getName());
            temp.setViews(p.getViews());
            temp.setOrders(p.getOrders());
        }
        return products;
    }

}
