package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class Store {

    private String name;
    private List<OnShelfProduct> mProduct;

    public Store() {

        name ="";
        mProduct = new ArrayList<>();
    }

    public Store(String name) {
        this.name = name;
        mProduct = new ArrayList<>();
    }

    OnShelfProduct searchByID(int id){

        for(OnShelfProduct p: mProduct){
            if(p.product.getId() == id){
                return p;
            }
        }
        return null;
    }

    OnShelfProduct searchByName(String name){

        for(OnShelfProduct p: mProduct){
            if(p.product.getName().equalsIgnoreCase(name)){
                return p;
            }
        }
        return null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    boolean addProduct(Product product, int quantity){

        if(searchByID(product.getId()) != null){
            mProduct.add(new OnShelfProduct(product));
            return true;
        }
        else
            return false;
    }

    boolean removeProduct(Product product){

        if(searchByID(product.getId()) != null){
            mProduct.remove(searchByID(product.getId()));
            return true;
        }
        else
            return false;
    }

    List<OnShelfProduct> copyToList(){

        List<OnShelfProduct> temp = new ArrayList<>();

        for(OnShelfProduct p: mProduct){
            temp.add(new OnShelfProduct(p.product, p.views, p.orders));
        }
        return temp;
    }

    List<OnShelfProduct> getAll(){ return mProduct; }
}
