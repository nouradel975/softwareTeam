package SoftwareProject;

public class Order {

    private OnShelfProduct product;
    private Buyer buyer;
    private float invoice;

    Order(){

        product = new OnShelfProduct();
        buyer = new Buyer();
        invoice = 0;
    }

    public Order(OnShelfProduct product, Buyer buyer, float invoice) {
        this.product = product;
        this.buyer = buyer;
        this.invoice = invoice;
    }

    public OnShelfProduct getProduct() { return product; }

    public void setProduct(OnShelfProduct product) { this.product = product; }

    public Buyer getBuyer() { return buyer; }

    public void setBuyer(Buyer buyer) { this.buyer = buyer; }

    public float getInvoice() { return invoice; }

    public void setInvoice(float invoice) { this.invoice = invoice; }

}
