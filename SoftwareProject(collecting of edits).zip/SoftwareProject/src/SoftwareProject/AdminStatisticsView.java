package SoftwareProject;

public class AdminStatisticsView {

    AdminStatController adminStatCtr;

    AdminStatisticsView(ProductController productCtr){

        adminStatCtr = new AdminStatController(productCtr);
        System.out.println(adminStatCtr.calStatistics());
    }
}
