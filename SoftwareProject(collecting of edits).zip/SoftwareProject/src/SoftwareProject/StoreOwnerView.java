package SoftwareProject;

import java.util.List;
import java.util.Scanner;

public class StoreOwnerView {

    private ProductController productCtr;
    private StoreController storeCtr;
    private StoreOwner owner;

    StoreOwnerView(){

        productCtr = new ProductController();
        storeCtr = new StoreController();
        owner = new StoreOwner();
    }

    void addStore() {

        System.out.print("store name: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        if(storeCtr.addStore(name))
            System.out.println("Done.");
        else
            System.out.println("Can't add, it's already exist.");
    }

    void removeStore(){

        System.out.print("store name: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        if(storeCtr.removeStore(name))
            System.out.println("Done.");
        else
            System.out.println("Can't remove, it's not exist.");
    }

    void addProduct(){

        System.out.print("product name: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        Product product = new Product();

        product.setName(name);

        System.out.print("price: ");
        product.setPrice(sc.nextFloat());

        System.out.print("category: ");
        product.setCategory(sc.next());

        System.out.print("size: ");
        product.setSize(sc.nextInt());

        System.out.print("color: ");
        product.setColor(sc.next());

        System.out.print("ID: ");
        product.setId(sc.nextInt());

        System.out.print("quantity: ");
        int quantity = sc.nextInt();

        if(owner.store.addProduct(product, quantity))
            System.out.println("Done.");
        else
            System.out.println("Can't add, is already exist.");
    }

    void removeProduct(){

        Scanner sc = new Scanner(System.in);
        System.out.print("product name: ");
        String name = sc.next();
        Product product = new Product();

        product.setName(name);

        if(owner.store.removeProduct(product))
            System.out.println("Done.");
        else
            System.out.println("Can't remove, not exist.");
    }

    void displayOneProduct(){

        Scanner sc = new Scanner(System.in);
        System.out.print("what's the product you want to see it's details: ");
        String name = sc.next();
        Product temp = new Product();
        temp.setName(name);
        Product product = owner.store.searchByName(temp.getName()).product;

        System.out.println("name: "+product.getName() +", price: "+
                product.getPrice() + ", category: " + product.getCategory()+ ", brand: "+ product.getBrand()
                +", size: " + product.getSize() + ", ID: " + product.getId() + ", color: "+product.getColor());
    }

    void explore(){

        for(OnShelfProduct p: owner.store.getAll()) {
            System.out.println("product" + p.product.getId() + ": " + p.product.getName());
        }
    }

    void suggest(){

        System.out.print("Please, suggest product: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();

        Product temp = new Product();
        temp.setName(name);

        System.out.print("price: ");
        temp.setPrice(sc.nextFloat());

        System.out.print("category: ");
        temp.setCategory(sc.next());

        System.out.print("size: ");
        temp.setSize(sc.nextInt());

        System.out.print("color: ");
        temp.setColor(sc.next());

        System.out.print("ID: ");
        temp.setId(sc.nextInt());

        productCtr.suggest(temp);
    }

    public void viewsForEachPro (Store store) {

        List<OnShelfProduct> pList= store.getAll();

        for (OnShelfProduct aPList : pList) {
            System.out.println("Product Name:" + aPList.product.getName() +
                    ", Views :" + aPList.getViews());
        }
    }

}
