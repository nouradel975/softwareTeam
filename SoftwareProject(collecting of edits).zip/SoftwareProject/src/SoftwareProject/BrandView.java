package SoftwareProject;

import java.util.Scanner;

public class BrandView {

    BrandController brandCtr;

    BrandView(){ brandCtr = new BrandController();}

    void addBrand(){

        System.out.print("what's the name of brand ? ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        if(brandCtr.addBrand(name))
            System.out.println("This brand " +name+ " is already found");
        else
            System.out.println("Done.");
    }

    void removeBrand(){

        System.out.print("What's the brand you want to remove it ? ");
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        if(brandCtr.removeBrand(name))
            System.out.println("Done.");
        else
            System.out.println("Brand not founded.");
    }
}
