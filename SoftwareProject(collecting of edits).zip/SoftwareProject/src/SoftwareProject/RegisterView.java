package SoftwareProject;

import java.util.Scanner;

public class RegisterView {

    AccountController ctr;

    RegisterView(){

        ctr = new AccountController();
    }

    void register(){

        Scanner sc = new Scanner(System.in);
        System.out.print("name: ");
        String name = sc.next();

        System.out.print("email: ");
        String email = sc.next();

        System.out.print("pass: ");
        String pass = sc.next();

        if(ctr.register(pass,name,email))
            System.out.println("welcome!! , now you have an account");
        else
            System.out.println("There is an account by this info.");
    }

    void login() {

        Scanner sc = new Scanner(System.in);

        System.out.print("email: ");
        String email = sc.next();

        System.out.print("pass: ");
        String pass = sc.next();

        while (!ctr.login(email, pass)) {

            System.out.print("email: ");
            email = sc.next();

            System.out.print("pass: ");
            pass = sc.next();
        }
    }
}
