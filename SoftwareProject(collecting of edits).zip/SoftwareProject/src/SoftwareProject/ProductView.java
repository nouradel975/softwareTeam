package SoftwareProject;

import java.util.List;
import java.util.Scanner;

public class ProductView {

    ProductController productCtr;

    ProductView(){productCtr = new ProductController();}

    void addProduct(){

        Scanner sc = new Scanner(System.in);
        Product product = new Product();

        System.out.println("you want to add product,, so please enter it's info.");
        System.out.print("product name: ");
        product.setName(sc.next());

        System.out.print("price: ");
        product.setPrice(sc.nextFloat());

        System.out.print("size: ");
        product.setSize(sc.nextInt());

        System.out.print("category: ");
        product.setCategory(sc.next());

        System.out.print("color: ");
        product.setColor(sc.next());

        if(productCtr.addProduct(product))
            System.out.println("Done.");
        else
            System.out.println("This Product " + product.getName() + " is already found");
    }

    void removeProduct(){

        Scanner sc = new Scanner(System.in);
        System.out.print("What's the name of the product you want to remove ? ");
        String name = sc.next();

        if(productCtr.removeProduct(name))
            System.out.println("Done.");
        else
            System.out.println("Product not founded.");
    }

    void display(){

        List<Product> temp = productCtr.getAll();

        for(Product p: temp){
            System.out.println("product name: " + p.getName() + ", size: " + p.getSize()+ ", price: "
                    + p.getPrice() +", brand: " +p.getBrand().getName()
                    + ", color: " + p.getColor() + ", category: " + p.getCategory());
        }
    }
}
