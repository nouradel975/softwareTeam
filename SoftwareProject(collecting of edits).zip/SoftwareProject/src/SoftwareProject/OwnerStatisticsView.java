package SoftwareProject;

public class OwnerStatisticsView {

    StatController statCtr;
    Store store;

    public OwnerStatisticsView(Store store){ this.store = store; }

    public OwnerStatisticsView() {

        statCtr = new StatController();
        statCtr.calStatistics(store);
    }
}
