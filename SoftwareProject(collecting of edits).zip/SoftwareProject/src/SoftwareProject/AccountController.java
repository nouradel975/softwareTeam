package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class AccountController {

    private List<Account> mAccounts;

    AccountController(){ mAccounts = new ArrayList<>();}

    boolean register(String pass, String name, String email){

        Account acc=new Account();
        acc.setName(name);
        acc.setPass(pass);
        acc.setEmail(email);

        if(!search(acc)){
            mAccounts.add(acc);
            return true;
        }
        else return false;
    }

    private boolean search(Account account){

        for(Account a: mAccounts){
            if(a.email.equals(account.email) && a.pass.equals(account.pass))
                return  true;
        }
        return false;
    }

    boolean login(String email, String pass){

        Account account = new Account();
        account.email = email;
        account.pass = pass;

        if(search(account)){
            System.out.println("welcome :)");
            return true;
        }
        else
            return false;

    }
}
