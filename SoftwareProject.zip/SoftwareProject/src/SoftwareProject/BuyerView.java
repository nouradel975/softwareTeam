package SoftwareProject;

public class BuyerView {

    OrderController orderCtr;
    ProductController productCtr;
    Buyer buyer;
    StoreOwner storeCtr;

    BuyerView(){

        orderCtr = new OrderController();
        productCtr = new ProductController();
        buyer = new Buyer();
        storeCtr = new StoreOwner();
    }

    void buy(OnShelfProduct product){}

    boolean pay(String ype){}

    void display(){}

}
