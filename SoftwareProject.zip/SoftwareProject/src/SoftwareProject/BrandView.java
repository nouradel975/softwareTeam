package SoftwareProject;

public class BrandView {

    BrandController brandCtr;

    void addBrand(){}

    void removeBrand(){}
}
