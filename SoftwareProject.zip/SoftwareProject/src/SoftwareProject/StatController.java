package SoftwareProject;

public class StatController {

    String calStatistics(Store store){}
}
