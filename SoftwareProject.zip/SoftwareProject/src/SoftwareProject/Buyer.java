package SoftwareProject;

public class Buyer extends Account {}
