package SoftwareProject;

public class ProductView {

    ProductController productCtr;

    ProductView(){productCtr = new ProductController();}

    void addProduct(){}

    void removeProduct(){}

    void display(){}
}
