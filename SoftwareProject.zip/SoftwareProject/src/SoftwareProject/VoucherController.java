package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class VoucherController {

    List<VoucherCard> mVouchers;

    VoucherController(){

        mVouchers = new ArrayList<>();
    }

    void addVoucher(String expiry, int balance){}

    void removeVoucher(VoucherCard voucher){}
}
