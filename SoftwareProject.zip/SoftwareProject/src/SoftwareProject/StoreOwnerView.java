package SoftwareProject;

public class StoreOwnerView {

    private ProductController productCtr;
    private StoreController storeCtr;
    private StoreOwner owner;

    StoreOwnerView(){

        productCtr = new ProductController();
        storeCtr = new StoreController();
        owner = new StoreOwner();
    }
    void addStore(){}

    void removeStore(){}

    void addProduct(){}

    void removeProduct(){}

    void display(){}

    void suggest(){}
}
