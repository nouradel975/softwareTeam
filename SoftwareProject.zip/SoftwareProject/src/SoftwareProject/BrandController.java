package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class BrandController {

    List<Brand> brands;
    List<Brand> suggestes;

    BrandController(){

        brands = new ArrayList<>();
        suggestes = new ArrayList<>();
    }

    void addBrand(String name){}

    void removeBrand(Brand brand){}

    void suggest(Brand brand){}

    public List<Brand> getSuggestes() {
        return suggestes;
    }


}
