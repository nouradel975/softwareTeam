package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class OrderController {

    protected List<Order> mOrders;

    public OrderController() { mOrders = new ArrayList<>(); }

    public List<Order> getmOrders() { return mOrders; }

    public void setmOrders(List<Order> mOrders) { this.mOrders = mOrders; }

    public void addOrder(Buyer buyer, int invoice, OnShelfProduct product){

    }

    public boolean payByVica(Buyer buyer, int price){

    }

    public boolean payByCash(Buyer buyer, int price){

    }

    public boolean payByVoucher(Buyer buyer, int price){

    }

}
