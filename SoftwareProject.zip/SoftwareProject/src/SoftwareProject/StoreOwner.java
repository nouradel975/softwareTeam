package SoftwareProject;

public class StoreOwner extends Account{

    Store store;

    StoreOwner(){ store = new Store(); }

    public Store getStore() { return store; }

    public void setStore(Store store) { this.store = store; }
}
