package SoftwareProject;

public class AdminStatisticsView {

    AdminStatController adminStatCtr;

    AdminStatisticsView(){ adminStatCtr = new AdminStatController();}
}
