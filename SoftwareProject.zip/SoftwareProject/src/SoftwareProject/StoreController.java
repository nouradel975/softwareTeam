package SoftwareProject;

import java.util.ArrayList;
import java.util.List;

public class StoreController {

    private List<Store> mStores;

    StoreController(){ mStores = new ArrayList<>();}

    void addStore(String name){

    }

    void removeStore(Store store){

    }

    List<Store> getAll(){

    }
}
