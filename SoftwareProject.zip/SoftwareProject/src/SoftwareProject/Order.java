package SoftwareProject;

public class Order {

    private OnShelfProduct product;
    private Buyer buyer;
    private int invoice;

    public OnShelfProduct getProduct() { return product; }

    public void setProduct(OnShelfProduct product) { this.product = product; }

    public Buyer getBuyer() { return buyer; }

    public void setBuyer(Buyer buyer) { this.buyer = buyer; }

    public int getInvoice() { return invoice; }

    public void setInvoice(int invoice) { this.invoice = invoice; }


}
